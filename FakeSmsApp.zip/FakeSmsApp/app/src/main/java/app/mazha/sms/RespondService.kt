package app.mazha.sms

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** مطلوب للتأهل كتطبيق رسائل افتراضي (الرد السريع على المكالمات). */
class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
