package app.mazha.sms

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // واجهة عربية RTL دائماً
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ar"))
    }
}
