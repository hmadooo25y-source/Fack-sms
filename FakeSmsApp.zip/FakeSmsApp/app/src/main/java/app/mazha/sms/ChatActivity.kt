package app.mazha.sms

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import app.mazha.sms.databinding.ActivityChatBinding
import app.mazha.sms.databinding.DialogMessageBinding
import app.mazha.sms.databinding.DialogScheduleBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Calendar
import kotlin.random.Random

class ChatActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "conv_id"
    }

    private lateinit var b: ActivityChatBinding
    private lateinit var store: Store
    private lateinit var adapter: MessageAdapter
    private lateinit var convId: String

    private val smsPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) send() else Toast.makeText(this, R.string.sms_perm_needed, Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra(EXTRA_ID)
        if (id == null) {
            finish()
            return
        }
        convId = id
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = Store(this)

        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.menu_chat)
        b.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_schedule -> showSchedule()
                R.id.action_rename -> rename()
                R.id.action_delete -> deleteChat()
            }
            true
        }

        adapter = MessageAdapter { m -> showMessageOptions(m) }
        b.list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        b.list.adapter = adapter

        b.toggle.check(R.id.btnMe)
        b.send.setOnClickListener { send() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val c = store.find(convId)
        if (c == null) {
            finish()
            return
        }
        b.toolbar.title = c.name
        b.toolbar.subtitle = c.phone
        adapter.submit(c.messages.sortedBy { it.time })
        if (adapter.itemCount > 0) b.list.scrollToPosition(adapter.itemCount - 1)
    }

    private fun send() {
        val text = b.input.text.toString().trim()
        if (text.isEmpty()) return
        val real = b.real.isChecked
        if (real) {
            val c = store.find(convId) ?: return
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                smsPerm.launch(Manifest.permission.SEND_SMS)
                return
            }
            try {
                @Suppress("DEPRECATION")
                val sm = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java)
                else SmsManager.getDefault()
                sm.sendMultipartTextMessage(c.phone, null, sm.divideMessage(text), null, null)
            } catch (e: Exception) {
                Toast.makeText(this, R.string.sms_send_failed, Toast.LENGTH_SHORT).show()
                return
            }
        }
        val sent = real || b.toggle.checkedButtonId == R.id.btnMe
        store.mutate(convId) { it.messages.add(Message(newId(), text, sent, System.currentTimeMillis())) }
        b.input.setText("")
        refresh()
    }

    private fun rename() {
        val c = store.find(convId) ?: return
        contactDialog(getString(R.string.edit_contact), c.name, c.phone) { n, p ->
            store.mutate(convId) { it.name = n; it.phone = p }
            refresh()
        }
    }

    private fun deleteChat() {
        MaterialAlertDialogBuilder(this)
            .setMessage(R.string.delete_chat_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                val all = store.load()
                all.removeAll { it.id == convId }
                store.save(all)
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showMessageOptions(m: Message) {
        MaterialAlertDialogBuilder(this)
            .setItems(arrayOf(getString(R.string.edit_message), getString(R.string.delete))) { _, which ->
                if (which == 0) editMessage(m) else {
                    store.mutate(convId) { c -> c.messages.removeAll { it.id == m.id } }
                    refresh()
                }
            }
            .show()
    }

    private fun editMessage(m: Message) {
        val v = DialogMessageBinding.inflate(layoutInflater)
        v.msgText.setText(m.text)
        val cal = Calendar.getInstance().apply { timeInMillis = m.time }
        v.btnTime.text = Fmt.msgTime(cal.timeInMillis)
        v.btnTime.setOnClickListener {
            TimePickerDialog(
                this,
                { _, h, min ->
                    cal.set(Calendar.HOUR_OF_DAY, h)
                    cal.set(Calendar.MINUTE, min)
                    v.btnTime.text = Fmt.msgTime(cal.timeInMillis)
                },
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false
            ).show()
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.edit_message)
            .setView(v.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val t = v.msgText.text.toString().trim()
                if (t.isNotEmpty()) {
                    store.mutate(convId) { c ->
                        c.messages.firstOrNull { it.id == m.id }?.let {
                            it.text = t
                            it.time = cal.timeInMillis
                        }
                    }
                    refresh()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSchedule() {
        val v = DialogScheduleBinding.inflate(layoutInflater)
        v.unit.check(R.id.btnSec)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.schedule_incoming)
            .setView(v.root)
            .setPositiveButton(R.string.schedule) { _, _ ->
                val text = v.schText.text.toString().trim()
                val n = v.schDelay.text.toString().toLongOrNull() ?: 10L
                if (text.isEmpty()) return@setPositiveButton
                val mult = if (v.unit.checkedButtonId == R.id.btnMin) 60_000L else 1_000L
                schedule(text, n * mult)
                Toast.makeText(this, R.string.scheduled_toast, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun schedule(text: String, delayMs: Long) {
        val am = getSystemService(AlarmManager::class.java)
        val i = Intent(this, IncomingReceiver::class.java)
            .putExtra("conv_id", convId)
            .putExtra("text", text)
        val pi = PendingIntent.getBroadcast(
            this, Random.nextInt(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delayMs, pi)
    }
}
