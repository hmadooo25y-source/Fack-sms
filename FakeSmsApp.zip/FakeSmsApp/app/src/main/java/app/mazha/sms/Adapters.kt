package app.mazha.sms

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import app.mazha.sms.databinding.ItemConversationBinding
import app.mazha.sms.databinding.ItemMsgInBinding
import app.mazha.sms.databinding.ItemMsgOutBinding

class ConversationAdapter(
    private val onClick: (Conversation) -> Unit,
    private val onLong: (Conversation) -> Unit
) : RecyclerView.Adapter<ConversationAdapter.VH>() {

    private var items: List<Conversation> = emptyList()

    fun submit(list: List<Conversation>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemConversationBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemConversationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val c = items[position]
        val ctx = h.b.root.context
        h.b.avatar.text = c.name.firstOrNull()?.uppercase() ?: "؟"
        h.b.avatar.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c.color)
        }
        h.b.name.text = c.name
        val last = c.last
        if (last == null) {
            h.b.snippet.text = ""
            h.b.time.text = ""
        } else {
            h.b.snippet.text = (if (last.sent) ctx.getString(R.string.you_prefix) else "") + last.text
            h.b.time.text = Fmt.listTime(last.time)
        }
        h.b.root.setOnClickListener { onClick(c) }
        h.b.root.setOnLongClickListener { onLong(c); true }
    }
}

class MessageAdapter(
    private val onLong: (Message) -> Unit
) : RecyclerView.Adapter<MessageAdapter.VH>() {

    private var items: List<Message> = emptyList()

    fun submit(list: List<Message>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(root: View, val text: TextView, val time: TextView) : RecyclerView.ViewHolder(root)

    override fun getItemViewType(position: Int) = if (items[position].sent) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == 1) {
            val b = ItemMsgOutBinding.inflate(inf, parent, false)
            VH(b.root, b.text, b.time)
        } else {
            val b = ItemMsgInBinding.inflate(inf, parent, false)
            VH(b.root, b.text, b.time)
        }
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val m = items[position]
        h.text.text = m.text
        h.time.text = Fmt.msgTime(m.time)
        h.text.setOnLongClickListener { onLong(m); true }
    }
}
