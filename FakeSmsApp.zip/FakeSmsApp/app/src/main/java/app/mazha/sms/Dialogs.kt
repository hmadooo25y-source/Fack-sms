package app.mazha.sms

import android.app.Activity
import app.mazha.sms.databinding.DialogContactBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun Activity.contactDialog(
    title: String,
    name: String,
    phone: String,
    onOk: (String, String) -> Unit
) {
    val v = DialogContactBinding.inflate(layoutInflater)
    v.name.setText(name)
    v.phone.setText(phone)
    MaterialAlertDialogBuilder(this)
        .setTitle(title)
        .setView(v.root)
        .setPositiveButton(R.string.ok) { _, _ ->
            val n = v.name.text.toString().trim()
            if (n.isNotEmpty()) onOk(n, v.phone.text.toString().trim())
        }
        .setNegativeButton(R.string.cancel, null)
        .show()
}
