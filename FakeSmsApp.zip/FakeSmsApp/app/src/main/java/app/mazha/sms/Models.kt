package app.mazha.sms

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

data class Message(val id: String, var text: String, val sent: Boolean, var time: Long)

data class Conversation(
    val id: String,
    var name: String,
    var phone: String,
    var color: Int,
    val messages: MutableList<Message> = mutableListOf()
) {
    val last: Message? get() = messages.maxByOrNull { it.time }
}

object Fmt {
    fun msgTime(t: Long): String =
        SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))

    fun listTime(t: Long): String {
        val a = Calendar.getInstance().apply { timeInMillis = t }
        val n = Calendar.getInstance()
        val same = a.get(Calendar.YEAR) == n.get(Calendar.YEAR) &&
            a.get(Calendar.DAY_OF_YEAR) == n.get(Calendar.DAY_OF_YEAR)
        return if (same) msgTime(t)
        else SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
    }
}

val AVATAR_COLORS = intArrayOf(
    0xFF1A73E8.toInt(), 0xFFD93025.toInt(), 0xFF188038.toInt(), 0xFFE37400.toInt(),
    0xFF9334E6.toInt(), 0xFF129EAF.toInt(), 0xFFC2185B.toInt(), 0xFF5F6368.toInt()
)

class Store(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("fake_sms", Context.MODE_PRIVATE)

    fun load(): MutableList<Conversation> {
        val out = mutableListOf<Conversation>()
        try {
            val arr = JSONArray(sp.getString("convs", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val msgs = mutableListOf<Message>()
                val ma = o.getJSONArray("messages")
                for (j in 0 until ma.length()) {
                    val m = ma.getJSONObject(j)
                    msgs.add(Message(m.getString("id"), m.getString("text"), m.getBoolean("sent"), m.getLong("time")))
                }
                out.add(Conversation(o.getString("id"), o.getString("name"), o.optString("phone", ""), o.getInt("color"), msgs))
            }
        } catch (e: Exception) {
            // بيانات تالفة: نبدأ من جديد
        }
        return out
    }

    fun save(list: List<Conversation>) {
        val arr = JSONArray()
        for (c in list) {
            val ma = JSONArray()
            for (m in c.messages) {
                ma.put(JSONObject().put("id", m.id).put("text", m.text).put("sent", m.sent).put("time", m.time))
            }
            arr.put(
                JSONObject().put("id", c.id).put("name", c.name).put("phone", c.phone)
                    .put("color", c.color).put("messages", ma)
            )
        }
        sp.edit().putString("convs", arr.toString()).apply()
    }

    fun findOrCreateByPhone(phone: String): String {
        val all = load()
        val key = phone.filter { it.isDigit() }.takeLast(9)
        val existing = if (key.length >= 7)
            all.firstOrNull { it.phone.filter { c -> c.isDigit() }.takeLast(9) == key }
        else all.firstOrNull { it.phone == phone }
        if (existing != null) return existing.id
        val c = Conversation(newId(), phone, phone, AVATAR_COLORS[all.size % AVATAR_COLORS.size])
        all.add(c)
        save(all)
        return c.id
    }

    fun find(id: String): Conversation? = load().firstOrNull { it.id == id }

    fun mutate(id: String, block: (Conversation) -> Unit) {
        val all = load()
        val c = all.firstOrNull { it.id == id } ?: return
        block(c)
        save(all)
    }
}
