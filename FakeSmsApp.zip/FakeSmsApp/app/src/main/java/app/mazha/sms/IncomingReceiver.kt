package app.mazha.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يستقبل المنبّه المجدول، يضيف الرسالة الواردة للمحادثة ويعرض إشعاراً. */
class IncomingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("conv_id") ?: return
        val text = intent.getStringExtra("text") ?: return
        var name = ""
        Store(context).mutate(id) {
            it.messages.add(Message(newId(), text, false, System.currentTimeMillis()))
            name = it.name
        }
        if (name.isEmpty()) return // المحادثة انحذفت
        Notifier.show(context, id, name, text)
    }
}
