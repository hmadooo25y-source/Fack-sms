package app.mazha.sms

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.app.role.RoleManager
import android.provider.Telephony
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import app.mazha.sms.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var store: Store
    private lateinit var adapter: ConversationAdapter

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = Store(this)

        adapter = ConversationAdapter(
            onClick = { c ->
                startActivity(Intent(this, ChatActivity::class.java).putExtra(ChatActivity.EXTRA_ID, c.id))
            },
            onLong = { c -> showOptions(c) }
        )
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        b.toolbar.inflateMenu(R.menu.menu_main)
        b.toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_default_sms) requestDefaultSms(true)
            true
        }

        b.fab.setOnClickListener {
            contactDialog(getString(R.string.new_contact), "", "") { name, phone ->
                val all = store.load()
                val color = AVATAR_COLORS[all.size % AVATAR_COLORS.size]
                val c = Conversation(newId(), name, phone, color)
                all.add(c)
                store.save(all)
                startActivity(Intent(this, ChatActivity::class.java).putExtra(ChatActivity.EXTRA_ID, c.id))
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!prefs.getBoolean("asked_default", false)) {
            prefs.edit().putBoolean("asked_default", true).apply()
            requestDefaultSms(false)
        }
    }

    private fun requestDefaultSms(userAsked: Boolean) {
        if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
            if (userAsked) Toast.makeText(this, R.string.already_default, Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
            }
        } else {
            roleLauncher.launch(
                Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val list = store.load().sortedByDescending { it.last?.time ?: 0L }
        adapter.submit(list)
        b.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showOptions(c: Conversation) {
        MaterialAlertDialogBuilder(this)
            .setTitle(c.name)
            .setItems(arrayOf(getString(R.string.edit), getString(R.string.delete))) { _, which ->
                if (which == 0) {
                    contactDialog(getString(R.string.edit_contact), c.name, c.phone) { n, p ->
                        store.mutate(c.id) { it.name = n; it.phone = p }
                        refresh()
                    }
                } else {
                    MaterialAlertDialogBuilder(this)
                        .setMessage(R.string.delete_chat_confirm)
                        .setPositiveButton(R.string.delete) { _, _ ->
                            val all = store.load()
                            all.removeAll { it.id == c.id }
                            store.save(all)
                            refresh()
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
            .show()
    }
}
