package app.mazha.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** مطلوب للتأهل كتطبيق رسائل افتراضي. رسائل MMS غير مدعومة حالياً. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {}
}
