package app.mazha.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** يستقبل رسائل SMS الحقيقية عندما يكون التطبيق هو الافتراضي. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val store = Store(context)
        val bySender = LinkedHashMap<String, StringBuilder>()
        for (p in parts) {
            val from = p.originatingAddress ?: continue
            bySender.getOrPut(from) { StringBuilder() }.append(p.messageBody ?: "")
        }
        for ((from, body) in bySender) {
            val id = store.findOrCreateByPhone(from)
            var name = from
            store.mutate(id) {
                it.messages.add(Message(newId(), body.toString(), false, System.currentTimeMillis()))
                name = it.name
            }
            Notifier.show(context, id, name, body.toString())
        }
    }
}
