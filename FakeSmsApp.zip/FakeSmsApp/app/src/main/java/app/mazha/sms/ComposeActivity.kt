package app.mazha.sms

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** يفتح محادثة من روابط sms:/smsto: القادمة من تطبيقات أخرى. */
class ComposeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val number = intent.data?.schemeSpecificPart
            ?.substringBefore('?')?.trim().orEmpty()
        if (number.isEmpty()) {
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            val id = Store(this).findOrCreateByPhone(number)
            startActivity(Intent(this, ChatActivity::class.java).putExtra(ChatActivity.EXTRA_ID, id))
        }
        finish()
    }
}
